library(shiny)
library(readxl)
library(dplyr)
library(writexl)

# Define the user interface
ui <- fluidPage(
  titlePanel("Dynamic Data Sorter"),
  
  sidebarLayout(
    sidebarPanel(
      fileInput("dataFile", "Choose the Excel File",
                accept = c(".xlsx")),
      fileInput("idFile", "Choose the Column ID List File",
                accept = c(".txt")),
      actionButton("sort", "Sort Data"),
      downloadButton("downloadData", "Download Sorted Data")
    ),
    mainPanel(
      tableOutput("sortedTable")
    )
  )
)

# Define server logic to read, sort, and download data
server <- function(input, output) {
  
  # Create a reactive value that will store the sorted data
  sorted_data <- reactiveVal()
  
  # Observe the sort button click
  observeEvent(input$sort, {
    req(input$dataFile)  # Require that the input is provided
    req(input$idFile)
    
    # Read the .txt file containing column IDs
    ids <- readLines(input$idFile$datapath)
    
    # Ensure the IDs are clean and without extra whitespace
    ids <- ids[ids != ""]
    
    # Read the Excel file
    data <- read_excel(input$dataFile$datapath)
    
    # Check and keep only the IDs that exist in the Excel file
    ids <- ids[ids %in% colnames(data)]
    
    # Sort the data frame based on the uploaded column IDs
    if(length(ids) > 0) {
      sorted <- data %>%
        select(c("Sample ID", ids))
      sorted_data(sorted)
    }
  })
  
  # Output the sorted data
  output$sortedTable <- renderTable({
    sorted_data()
  })
  
  # Download handler for the sorted data
  output$downloadData <- downloadHandler(
    filename = function() {
      paste("sorted-data-", Sys.Date(), ".xlsx", sep="")
    },
    content = function(file) {
      sorted <- sorted_data()
      write_xlsx(sorted, file)
    }
  )
}

# Run the application 
shinyApp(ui = ui, server = server)
