library(shiny)

# Define UI
ui <- fluidPage(
  titlePanel("Download Sorted Headers CSV"),
  sidebarLayout(
    sidebarPanel(
      fileInput("file", "Choose CSV File"),
      actionButton("processData", "Process Data")
    ),
    mainPanel(
      downloadButton("downloadCSV", "Download Sorted Headers"),
      tableOutput("dataSummary"),
      #h3("No Growth"),
      tableOutput("variantGrowthTable")
    )
  )
)

# Define server logic
server <- function(input, output, session) {
  # Reactive function to read CSV data
  data <- reactive({
    req(input$file)
    read.csv(input$file$datapath)
  })
  
  # Reactive function to process data
  processed_data <- reactive({
    req(input$file)
    data_df <- read.csv(input$file$datapath)
    row_names <- LETTERS[1:8]
    rownames(data_df) <- row_names
    indices <- which(data_df == 2, arr.ind = TRUE)
    row_headers <- rownames(data_df)[indices[, 1]]
    col_headers <- colnames(data_df)[indices[, 2]]
    combined_headers <- paste(row_headers, col_headers, sep = " ")
    sorted_headers <- sort(combined_headers)
    sorted_headers_df <- data.frame(sorted_headers)
    colnames(sorted_headers_df) <- "Variant Growth"
    sorted_headers_df
  })
  
  # Process data when the button is clicked
  observeEvent(input$processData, {
    output$dataSummary <- renderTable({
      data()
    })
    output$variantGrowthTable <- renderTable({
      processed_data()
    })
  })
  
  # Download CSV file
  output$downloadCSV <- downloadHandler(
    filename = function() {
      "sorted_headers.csv"
    },
    content = function(file) {
      write.csv(processed_data(), file, row.names = FALSE)
    }
  )
}

# Run the Shiny app
shinyApp(ui = ui, server = server)
